package com.example.iaitmansour.myfoot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.iaitmansour.myfoot.Utils.CreateClubDataService;
import com.example.iaitmansour.myfoot.Utils.FileUtils;
import com.example.iaitmansour.myfoot.Utils.ServiceGenerator;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddClubActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST = 100;
    private int PICK_IMAGE_FROM_GALLERY_REQUEST = 1;
    private int PICK_IMAGE_FROM_GALLERY_REQUESTT = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_club);



        String title = "Liste des clubs";
        Toolbar mToolbar = findViewById(R.id.toolbar_add_club);
        mToolbar.setTitle(title);
        mToolbar.setTitleTextColor(Color.WHITE);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);


        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });



        Button mCreateClub = (Button) findViewById(R.id.createClubButton);
        mCreateClub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final EditText mNameClub = (EditText) findViewById(R.id.nameClub);
                final EditText mNamePresident = (EditText) findViewById(R.id.namePresident);
                final EditText mEmail = (EditText) findViewById(R.id.email);
                final EditText mPassword = (EditText) findViewById(R.id.password);

                if( mNameClub.getText().toString().equals("") || mNamePresident.getText().toString().equals("") || !isEmailValid(mEmail.getText().toString()) || mPassword.getText().toString().equals("") ){
                    Toast.makeText(AddClubActivity.this, "Merci de bien vouloir saisir tous les champs",
                            Toast.LENGTH_LONG).show();
                }
                else {

                    uploadFile();
                }
            }
        });

        if (ContextCompat.checkSelfPermission(AddClubActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AddClubActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST);
        }


        Button mLogo = (Button) findViewById(R.id.logoButton);
        mLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(
                        Intent.createChooser(intent, "Select Picture"),PICK_IMAGE_FROM_GALLERY_REQUEST);

            }
        });

        Button mLicense = (Button) findViewById(R.id.licenseButton);
        mLicense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentLicense = new Intent();
                intentLicense.setType("image/*");
                intentLicense.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(
                        Intent.createChooser(intentLicense, "Select Picturee"),PICK_IMAGE_FROM_GALLERY_REQUESTT);

            }
        });

    }

    Uri uri = null;
    Uri uriLicense = null;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        if((requestCode == PICK_IMAGE_FROM_GALLERY_REQUEST && resultCode == RESULT_OK && data != null && data.getData() !=null)){
            uri = data.getData();
        }
        if((requestCode == PICK_IMAGE_FROM_GALLERY_REQUESTT && resultCode == RESULT_OK && data != null && data.getData() !=null)){
            uriLicense = data.getData();
        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[]grantResults){
        switch(requestCode){
            case MY_PERMISSIONS_REQUEST:{
                if(grantResults.length >0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED){

                }
                else{

                }
            }
            return;
        }
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }


    public class ResponseUpload{

        @SerializedName("error")
        @Expose
        private Boolean error;
        @SerializedName("message_user")
        @Expose
        private String messageUser;
        @SerializedName("message")
        @Expose
        private String message;


        public String getMessageUser() {
            return messageUser;
        }

        public Boolean getError() {
            return error;
        }

        public String getMessage() {
            return message;
        }
    }

    //Upload new club function
    private void uploadFile(){

        // create upload service client
        CreateClubDataService service =
                ServiceGenerator.createService(CreateClubDataService.class);


        File file = FileUtils.getFile(this, uri);
        File fileLicense = FileUtils.getFile(this, uriLicense);

        // create RequestBody instance from file
        RequestBody requestFile =
                RequestBody.create(
                        MediaType.parse(getContentResolver().getType(uri)),
                        file
                );

        RequestBody requestFileLicense =
                RequestBody.create(
                        MediaType.parse(getContentResolver().getType(uriLicense)),
                        fileLicense
                );

        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("logo", file.getName(), requestFile);

        MultipartBody.Part bodyLicense =
                MultipartBody.Part.createFormData("license", fileLicense.getName(), requestFileLicense);




        final EditText mNameClub = (EditText) findViewById(R.id.nameClub);
        final EditText mNamePresident = (EditText) findViewById(R.id.namePresident);
        final EditText mEmail = (EditText) findViewById(R.id.email);
        final EditText mPassword = (EditText) findViewById(R.id.password);
        String mrole = "president";

        RequestBody nameClubPart = RequestBody.create(MultipartBody.FORM, mNameClub.getText().toString());
        RequestBody namePresidentPart = RequestBody.create(MultipartBody.FORM, mNamePresident.getText().toString());
        RequestBody emailPart = RequestBody.create(MultipartBody.FORM, mEmail.getText().toString());
        RequestBody passwordPart = RequestBody.create(MultipartBody.FORM, mPassword.getText().toString());
        RequestBody role = RequestBody.create(MultipartBody.FORM, mrole);

        // finally, execute the request
        Call<ResponseUpload> call = service.uploadPhoto(nameClubPart,namePresidentPart,emailPart,passwordPart,role,body, bodyLicense);
        call.enqueue(new Callback<ResponseUpload>() {
            @Override
            public void onResponse(Call<ResponseUpload> call,
                                   Response<ResponseUpload> response) {

                Toast.makeText(AddClubActivity.this, response.body().getMessageUser(),
                        Toast.LENGTH_LONG).show();


            }

            @Override
            public void onFailure(Call<ResponseUpload> call, Throwable t) {
                Log.e("Upload error:", t.getMessage());
            }
        });
    }




}
