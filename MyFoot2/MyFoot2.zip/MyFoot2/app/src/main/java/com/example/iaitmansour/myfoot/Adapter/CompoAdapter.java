package com.example.iaitmansour.myfoot.Adapter;

import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;

import com.example.iaitmansour.myfoot.Models.Classement;
import com.example.iaitmansour.myfoot.Models.CompositionMatch;
import com.example.iaitmansour.myfoot.R;

import java.util.List;

/**
 * Created by iaitmansour on 30/06/2018.
 */

public class CompoAdapter extends RecyclerView.Adapter<CompoAdapter.ViewHolder>{

    private Context context;
    private List<CompositionMatch> list;





    public CompoAdapter(Context context, List<CompositionMatch> list){
        this.context=context;
        this.list=list;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent,int viewType){

        View v= LayoutInflater.from(context).inflate(R.layout.single_compo_item,parent,false);


        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(ViewHolder holder,int position){
        CompositionMatch compo=list.get(position);


        String nameLower = String.valueOf(compo.getLineup_player().toLowerCase().replaceAll("([^a-zA-Z]|\\s)+", ""));
        int id = context.getResources().getIdentifier(nameLower, "drawable", context.getPackageName());

        holder.namePlayer.setText(String.valueOf(compo.getLineup_player()));
        holder.numberPlayer.setText(String.valueOf(compo.getLineup_number()));
        holder.compo_img.setImageResource(id);


    }

    @Override
    public int getItemCount(){
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView namePlayer, numberPlayer;
        public ImageView compo_img;

        public ViewHolder(View itemView) {
            super(itemView);


            namePlayer = itemView.findViewById(R.id.compo_joueur);
            numberPlayer = itemView.findViewById(R.id.compo_numero);
            compo_img = itemView.findViewById(R.id.compo_img);


        }
    }


}
